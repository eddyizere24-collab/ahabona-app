# AHABONA (real application)

Node 22.5+ server with **zero npm dependencies** (`node:sqlite`), serving the AHABONA front-end from `public/`.
All persistent data (accounts, profiles, photos, saved profiles, reports, device discovery state, intent, admin audit) lives on the server in `AHABONA_DATA` (SQLite file + `photos/`).

## Run locally
```
ADMIN_EMAIL=you@example.com ADMIN_PHONE=0788000000 ADMIN_PASSWORD='a-long-password' node --no-warnings server.js
# http://localhost:3000   admin: http://localhost:3000/admin
```

## Environment
| Variable | Purpose |
|---|---|
| `PORT` | listen port (default 3000) |
| `AHABONA_DATA` | **persistent** directory for `ahabona.db` and `photos/` (mount a disk/volume!) |
| `ADMIN_EMAIL`, `ADMIN_PHONE`, `ADMIN_PASSWORD` | creates the first admin on start (if it does not exist) |
| `AHABONA_SECURE=1` | set when served over HTTPS: adds `Secure` cookies + HSTS |
| `AHABONA_TRUST_PROXY=1` | behind a reverse proxy: use `X-Forwarded-For` for rate limiting |
| `AHABONA_URL` | public base URL, used in password-reset emails (e.g. `https://ahabona.rw`) |
| `MAIL_API_URL`, `MAIL_API_KEY`, `MAIL_FROM` | transactional-email HTTP API (POST JSON `{from,to,subject,text}`, Bearer key). Without it, reset emails are NOT sent |
| `AHABONA_DEV=1` | tests only (exposes dev mailbox). **Never in production** |

## Deploy
Any host that runs Node >= 22.5 or Docker **with a persistent disk** and HTTPS (e.g. Fly.io, Render, Railway, a VPS behind Caddy/nginx).
`docker build -t ahabona . && docker run -p 3000:3000 -v ahabona-data:/data -e ADMIN_EMAIL=... -e ADMIN_PHONE=... -e ADMIN_PASSWORD=... -e AHABONA_SECURE=1 ahabona`
Back up `AHABONA_DATA` regularly. Single instance only (SQLite + in-memory rate limits).

## Tests
```
node --no-warnings test/api.test.js     # 55 API/security/lifecycle tests (temp DB, injected clock)
python3 test/e2e.py                      # 67 real-browser checks (Chromium, 4+ separate "devices", mobile viewport)
```
Legal pages `/terms` and `/privacy` are DRAFTS that need lawyer review and operator details before launch.
