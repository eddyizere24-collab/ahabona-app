'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {start}=require('../server.js');
(async()=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'ahabona-admin-perms-'));
 const old={ADMIN_EMAIL:process.env.ADMIN_EMAIL,ADMIN_PHONE:process.env.ADMIN_PHONE,ADMIN_PASSWORD:process.env.ADMIN_PASSWORD};
 Object.assign(process.env,{ADMIN_EMAIL:'owner@ahabona.rw',ADMIN_PHONE:'0788000000',ADMIN_PASSWORD:'OwnerPass12345'});
 const app=start({dataDir});
 try{
  const port=await app.listen(0),base=`http://127.0.0.1:${port}`;
  async function req(method,url,body,cookie){const r=await fetch(base+url,{method,headers:{...(body?{'content-type':'application/json'}:{}),...(cookie?{cookie}:{})},body:body?JSON.stringify(body):undefined});let j={};try{j=await r.json()}catch{}return {status:r.status,j,cookie:r.headers.get('set-cookie')?.split(';')[0]}}
  await app.boot;
  const owner=await req('POST','/api/login',{id:'owner@ahabona.rw',password:'OwnerPass12345'});assert.equal(owner.status,200);
  const created=await req('POST','/api/admin/staff',{email:'staff@ahabona.rw',phone:'0788000001',password:'StaffPass12345',permissions:['users_view']},owner.cookie);assert.equal(created.status,201);
  const staff=await req('POST','/api/login',{id:'staff@ahabona.rw',password:'StaffPass12345'});assert.equal(staff.status,200);
  const users=await req('GET','/api/admin/users',null,staff.cookie);assert.equal(users.status,200);assert.ok(users.j.users.every(x=>x.email===null&&x.phone===null),'PII must stay hidden without users_sensitive_view');
  assert.equal((await req('GET','/api/admin/reports',null,staff.cookie)).status,403,'permission not granted must be denied');
  assert.equal((await req('GET','/api/admin/staff',null,staff.cookie)).status,403,'delegated staff cannot manage other admins');
  const escalation=await req('POST','/api/admin/staff',{email:'escalate@ahabona.rw',phone:'0788000002',password:'EscalatePass123',permissions:['staff_manage']},owner.cookie);assert.equal(escalation.status,400,'staff_manage cannot be delegated');
  assert.equal((await req('POST','/api/admin/staff/'+created.j.id,{action:'suspend'},owner.cookie)).status,200);
  assert.ok([401,403].includes((await req('GET','/api/admin/users',null,staff.cookie)).status),'suspending staff revokes active session');
  console.log('PASS admin delegation, permission boundaries, PII protection, privilege-escalation prevention, and session revocation');
 }finally{app.close();fs.rmSync(dataDir,{recursive:true,force:true});for(const k of Object.keys(old)){if(old[k]===undefined)delete process.env[k];else process.env[k]=old[k]}}
})().catch(e=>{console.error(e);process.exitCode=1});
