import subprocess,os,time,json,tempfile,urllib.request,sys,io
from PIL import Image
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def start_server(port):
    d=tempfile.mkdtemp(prefix='ahb-e2e-')
    env=dict(os.environ,PORT=str(port),AHABONA_DATA=d,AHABONA_DEV='1',AHABONA_TRUST_PROXY='1',ADMIN_EMAIL='admin@ahabona.rw',ADMIN_PHONE='0788999999',ADMIN_PASSWORD='AdminPass123')
    p=subprocess.Popen(['node','--no-warnings','server.js'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    for _ in range(50):
        try:
            urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=1);return p,d
        except Exception: time.sleep(.2)
    raise RuntimeError('server did not start')
def make_photo(path,color=(200,120,60),size=(900,700)):
    im=Image.new('RGB',size,color)
    for x in range(0,size[0],40):
        for y in range(0,size[1],40):
            if (x//40+y//40)%2:im.paste((255,255,255),(x,y,x+20,y+20))
    im.save(path,'JPEG',quality=92);return path
class Rec:
    def __init__(s):s.ok=0;s.bad=[]
    def check(s,name,cond,info=''):
        if cond:s.ok+=1;print('  PASS',name)
        else:s.bad.append(name);print('  FAIL',name,info)
