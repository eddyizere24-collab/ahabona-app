# AHABONA — deployment package

Node.js 22.5+ application with the current front-end embedded in `server.js`.

## Run

```sh
npm start
```

Set `AHABONA_DATA` to a persistent directory/volume for SQLite and uploaded photos. Set `ADMIN_EMAIL`, `ADMIN_PHONE`, and `ADMIN_PASSWORD` for initial admin creation. On Render, keep a persistent disk mounted for the data directory and configure the service's start command as `npm start` or `node --no-warnings server.js`.

## Verification

```sh
npm run test:api
```

The search history is stored locally in the user's browser (up to six recent searches). Search terms are not tied to an account in the history UI. The server also retains aggregate search logs for admin metrics.

The update adds safe SQLite indexes for common lookups, replaces the home-feed N+1 profile query with a single batch query, and recognizes a district typed as part of the search phrase (for example, `umudozi i Huye`). It keeps the original search phrase in aggregate logs while using the extracted district to filter results.


## Admin permissions

The `admin` role created from `ADMIN_EMAIL`, `ADMIN_PHONE`, and `ADMIN_PASSWORD` is the owner-level administrator. It retains full access. Owner admins can create delegated `staff` accounts from `/admin`, assign only the permissions needed for each task, revise permissions, suspend/restore delegated admins, and reset their passwords. The `staff_manage` permission is intentionally not delegable.

Delegated permissions include dashboard access, user-list access, sensitive contact visibility, account management, profile moderation, report handling, capability/category requests, analytics, audit-history access, and sending account messages. Email and phone fields are omitted from the API response unless `users_sensitive_view` is granted. Administrative changes are recorded in the audit log. Suspending a delegated admin revokes their sessions; suspending a user account blocks login and authenticated requests. Permanent account deletion is restricted to the owner-level admin and requires typing the exact confirmation phrase shown by the interface.

The permissions column and the category/message tables are added with non-destructive SQLite migrations; existing accounts and profiles are preserved. Owners and delegated staff with `messages_send` can send in-app messages to user accounts; users see unread messages after signing in and can mark them read. The category manager can add/rename/activate/deactivate categories and add/edit/activate/deactivate capabilities; categories and capabilities are reflected in `/api/config` and the registration form. Items are deactivated rather than hard-deleted so historical profile references are not broken.

Run all test suites after changes:

```sh
npm run test:api
npm run test:admin
npm run test:completion
```

Browser end-to-end tests are included, but require the configured Playwright Chromium browser to be installed in the test environment.


## Remaining review before production

- `terms.html` and `privacy.html` are drafts and need qualified legal review.
- Browser E2E testing requires Playwright Chromium; if that browser is unavailable, only API/security/syntax tests can be reported as passing.
- This ZIP is a code package. It does not automatically push commits to GitHub or deploy to Render. Back up the production database and verify the Render persistent disk/environment variables before deploying.
