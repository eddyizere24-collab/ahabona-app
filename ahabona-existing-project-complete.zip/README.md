# AHABONA — complete update for the EXISTING project

This package is an update to the existing AHABONA Node.js application, not a new project. The Render entry point remains `server.js`; the latest browser interface is also embedded in `server.js` because that is what the live service starts. Keep the project root layout: `server.js` and `package.json` must be in the repository root.

## What is included

- Existing registration, login, shared profiles, profile editing, search/discovery, saved profiles, reports, password reset, account lifecycle and security behavior.
- Password confirmation during registration (validated in browser and server).
- Owner administrator and delegated staff permissions, with server-side authorization and sensitive-contact protection.
- Suspend/restore accounts and profiles; owner-only safeguarded permanent account deletion.
- Admin audit history.
- In-app messages from authorized administrators to users, including read state.
- Admin category/capability management with changes reflected in configuration and registration.
- Admin profile corrections and audit records.
- Tests and deployment notes.

## Local run

Requires Node.js >= 22.5.

```sh
npm start
```

Configure the existing production environment variables rather than replacing them blindly: `ADMIN_EMAIL`, `ADMIN_PHONE`, `ADMIN_PASSWORD`, and `AHABONA_DATA`. `AHABONA_DATA` should point to persistent storage. Back up the live database and uploaded photos before deployment.

## Tests performed on this package

- `node --check server.js` — passed.
- `node --check app.js` — passed.
- `node --check admin.js` — passed.
- `node --no-warnings test/api.test.js` — 55 passed, 0 failed.
- `node --no-warnings test/admin-permissions.test.js` — passed.
- `node --no-warnings test/admin-completion.test.js` — passed.
- `python3 test/e2e.py` — not completed because Playwright Chromium is not installed in the test environment. Do not treat browser E2E as passed.

## IMPORTANT: update the existing GitHub repository

1. Download and extract this ZIP on a computer or phone that can extract ZIP files.
2. Open the extracted folder. Upload/replace the actual project files in the existing repository root. Do NOT upload this ZIP as a repository file and expect Render to unpack it.
3. Ensure `server.js` and `package.json` sit at the repository root beside `README.md`; do not put them inside an extra nested folder.
4. Commit the replacement files to the existing `main` branch. Do not create a separate app/repository.
5. Confirm Render deploys the new commit. The commit ID shown in Render must match the commit containing these changes.
6. After deployment, open the live site and test registration, login, search, profile editing, messages and admin functions. A green “Deploy succeeded” alone only confirms the server started; it does not prove every UI path works.

## Production cautions

- This package does not itself push changes to GitHub or deploy to Render.
- Keep the existing persistent disk and environment variables; do not wipe production data.
- Terms and Privacy are drafts and require qualified legal review.
- Browser E2E testing must be rerun in an environment with Playwright Chromium installed.
