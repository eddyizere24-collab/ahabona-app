'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {start}=require('../server.js');
(async()=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'ahabona-completion-'));
 const env={ADMIN_EMAIL:process.env.ADMIN_EMAIL,ADMIN_PHONE:process.env.ADMIN_PHONE,ADMIN_PASSWORD:process.env.ADMIN_PASSWORD};
 Object.assign(process.env,{ADMIN_EMAIL:'owner@ahabona.rw',ADMIN_PHONE:'0788111000',ADMIN_PASSWORD:'OwnerPass12345'});
 const app=start({dataDir});
 try{
  const port=await app.listen(0),base=`http://127.0.0.1:${port}`;
  async function req(method,url,body,cookie){const r=await fetch(base+url,{method,headers:{...(body?{'content-type':'application/json'}:{}),...(cookie?{cookie}:{})},body:body?JSON.stringify(body):undefined});let j={};try{j=await r.json()}catch{}return{status:r.status,j,cookie:r.headers.get('set-cookie')?.split(';')[0]}}
  await app.boot;
  const owner=await req('POST','/api/login',{id:'owner@ahabona.rw',password:'OwnerPass12345'});assert.equal(owner.status,200);
  const target=Number(app.db.prepare("INSERT INTO users(email,phone,pw,role,status,terms_at,created_at) VALUES(?,?,?,'user','active',?,?)").run('target@ahabona.rw','0788111001','testhash',Date.now(),Date.now()).lastInsertRowid);
  app.db.prepare("INSERT INTO profiles(user_id,pid,name,district,caps,phones,svc,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)").run(target,'testpid001','Test User','Gasabo','[]','[]','[]',Date.now(),Date.now());
  const cat=await req('POST','/api/admin/categories',{action:'create',name:'Serivisi z’ikizamini'},owner.cookie);assert.equal(cat.status,201);
  const cap=await req('POST','/api/admin/capabilities',{action:'create',name:'Umukozi w’ikizamini',category:'Serivisi z’ikizamini'},owner.cookie);assert.equal(cap.status,201);
  const config=await req('GET','/api/config');assert.deepEqual(config.j.categories['Serivisi z’ikizamini'],['Umukozi w’ikizamini']);
  const sent=await req('POST','/api/admin/messages',{user_id:target,title:'Amakuru kuri konti',message:'Turagusaba gusuzuma amakuru yawe.'},owner.cookie);assert.equal(sent.status,201);
  const messages=await req('GET','/api/admin/messages',null,owner.cookie);assert.equal(messages.status,200);assert.equal(messages.j.messages.length,1);assert.equal(messages.j.messages[0].user_id,target);
  const token='test-session-token';app.db.prepare('INSERT INTO sessions(th,user_id,expires) VALUES(?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'),target,Date.now()+60000);const inbox=await req('GET','/api/me/messages',null,'ahs='+token);assert.equal(inbox.status,200);assert.equal(inbox.j.messages.length,1);assert.equal((await req('POST','/api/me/messages/'+sent.j.id+'/read',{},'ahs='+token)).status,200);
  const corrected=await req('POST','/api/admin/profiles/testpid001/edit',{name:'Corrected Name',district:'Huye',intro:'Amakuru yakosowe',edu:'Amasomo'},owner.cookie);assert.equal(corrected.status,200);assert.equal(app.db.prepare('SELECT name,district FROM profiles WHERE pid=?').get('testpid001').district,'Huye');
  const adminPage=await fetch(base+'/admin.js');assert.equal(adminPage.status,200);assert.match(await adminPage.text(),/messages_send/);const appPage=await fetch(base+'/app.js');assert.equal(appPage.status,200);const servedClient=await appPage.text();assert.match(servedClient,/messagesRead/);assert.ok(servedClient.includes('id=\"rw2\"'));assert.ok(servedClient.includes('passwordConfirm:$(\"rw2\").value'));
  const fs=require('node:fs');
const client=fs.readFileSync(require('node:path').join(__dirname,'..','app.js'),'utf8');
const html=fs.readFileSync(require('node:path').join(__dirname,'..','index.html'),'utf8');
assert.ok(client.includes('passwordConfirm:$('+'"rw2"'+').value'),'registration sends the confirmation password');
assert.ok(client.includes('id=\"rw2\"'),'registration UI contains the password confirmation field');
assert.ok(client.includes('id=\"ewc\"'),'registration UI displays confirmation validation');
assert.ok(client.includes('Konti n’amafoto bibikwa kuri AHABONA'),'registration privacy note accurately describes server storage');
console.log('PASS dynamic category/capability CRUD, live config propagation, admin-to-user messages/read state, profile correction/audit, password confirmation and privacy-note regression checks');
 }finally{app.close();fs.rmSync(dataDir,{recursive:true,force:true});for(const k of Object.keys(env)){if(env[k]===undefined)delete process.env[k];else process.env[k]=env[k]}}
})().catch(e=>{console.error(e);process.exitCode=1});
