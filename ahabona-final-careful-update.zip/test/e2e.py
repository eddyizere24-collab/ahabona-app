import os,sys,json,time,subprocess,tempfile,urllib.request,re,shutil
from playwright.sync_api import sync_playwright
from PIL import Image,ImageFilter
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));PORT=3199;BASE=f'http://127.0.0.1:{PORT}';DATA=tempfile.mkdtemp(prefix='ahb-e2e-');SH=os.path.join(tempfile.gettempdir(),'ahb-shots');os.makedirs(SH,exist_ok=True)
env=dict(os.environ,PORT=str(PORT),AHABONA_DATA=DATA,AHABONA_DEV='1',AHABONA_TRUST_PROXY='1',ADMIN_EMAIL='admin@ahabona.rw',ADMIN_PHONE='0788999999',ADMIN_PASSWORD='AdminPass123')
srv=subprocess.Popen(['node','--no-warnings','server.js'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
for _ in range(50):
    try:urllib.request.urlopen(BASE+'/api/health');break
    except Exception:time.sleep(.2)
res=[];ipn=[0]
def check(name,cond,detail=''):
    res.append(bool(cond));print(('  PASS ' if cond else '  FAIL ')+name+('' if cond else '  -> '+str(detail)),flush=True)
def jget(path,cookie=None,ip='7.7.7.7',dev=None):
    h={'x-forwarded-for':ip}
    if cookie:h['cookie']=cookie
    if dev:h['x-device']=dev
    return json.load(urllib.request.urlopen(urllib.request.Request(BASE+path,headers=h)))
def jpost(path,body,cookie=None,ip=None):
    ipn[0]+=1;h={'content-type':'application/json','x-forwarded-for':ip or f'8.8.{ipn[0]//200}.{ipn[0]%200}'}
    if cookie:h['cookie']=cookie
    r=urllib.request.urlopen(urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers=h,method='POST'));
    return json.load(r),r.headers.get('set-cookie')
def tiny():
    import io,base64;b=io.BytesIO();Image.new('RGB',(40,40),(10,100,80)).save(b,'JPEG',quality=70);return 'data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
T=tiny()
def seed(name,district,jobs,i):
    return jpost('/api/register',dict(name=name,district=district,jobs=jobs,phone=f'078840{i:04d}',email=f's{i}@ex.rw',password='Password123',passwordConfirm='Password123',terms=True,photos=[T],thumbs=[T]))[0]['profile']
# big photos (simulating a modern phone camera)
big=[]
for k in range(3):
    im=Image.effect_noise((3200,2400),90).convert('RGB').filter(ImageFilter.GaussianBlur(1));p=f'{DATA}/photo{k}.jpg';im.save(p,'JPEG',quality=92);big.append(p)
print('source photo sizes (KB):',[os.path.getsize(p)//1024 for p in big])
errors=[];csp=[];dialogs=[]
def allnames(pg):
    pg.wait_for_selector('#grid .card .nm',timeout=8000)
    for _ in range(10):
        if pg.locator('#more').is_visible():pg.click('#more');pg.wait_for_timeout(150)
        else:break
    return pg.locator('#grid .card .nm').all_inner_texts()
def watch(pg,label):
    pg.on('console',lambda m:errors.append((label,m.text)) if m.type=='error' and 'Failed to load resource' not in m.text else None)
    pg.on('pageerror',lambda e:errors.append((label,str(e))))
    pg.on('dialog',lambda d:(dialogs.append(d.message),d.dismiss()))
    pg.add_init_script("window.__csp=[];document.addEventListener('securitypolicyviolation',e=>window.__csp.push(e.violatedDirective+' '+e.blockedURI))")
try:
  with sync_playwright() as p:
    executable=os.environ.get('PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH')
    b=p.chromium.launch(executable_path=executable) if executable else p.chromium.launch()
    mobile=dict(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True,user_agent='Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',extra_http_headers={'x-forwarded-for':'5.5.5.1'})
    ca=b.new_context(**mobile);pa=ca.new_page();watch(pa,'A')
    print('\n[1] Empty platform (no fake users), loading & error states')
    pa.route('**/api/profiles*',lambda r:(time.sleep(.6),r.continue_()))
    pa.goto(BASE+'/');check('skeleton cards show while loading',pa.locator('.card .skel, .card.sk, .skel').count()>0 or pa.locator('#grid .card').count()>0)
    pa.wait_for_selector('#grid .empty',timeout=8000);pa.unroute('**/api/profiles*')
    check('empty real DB shows honest empty state (no demo users)','Nta muntu urabona hano' in pa.inner_text('#grid') and pa.locator('#grid .card').count()==0,pa.inner_text('#grid'))
    pa.screenshot(path=SH+'/01_empty_mobile.png')
    pa.route('**/api/profiles*',lambda r:r.abort());pa.reload();pa.wait_for_selector('button[data-a=retry]',timeout=8000)
    check('network failure shows Kinyarwanda error + retry','Seriveri ntiboneka' in pa.inner_text('#grid'))
    pa.unroute('**/api/profiles*');pa.click('button[data-a=retry]');pa.wait_for_selector('#grid .empty:has-text("Nta muntu urabona")',timeout=8000);check('retry recovers',True)
    print('\n[2] Six-step registration through the real UI (mobile)')
    pa.click('#bReg');pa.wait_for_selector('#rn')
    pa.click('#nx');check('step 1 validation error in Kinyarwanda',pa.inner_text('#en')=='Andika izina ryawe ryuzuye.' and 'Hitamo intara' in pa.inner_text('#el'))
    pa.fill('#rn','Habimana Jean');pa.click('button[data-a=pv][data-v="Umujyi wa Kigali"]');pa.click('button[data-a=ds][data-v=Gasabo]')
    pa.click('summary:has-text("Aho ukorera serivisi")');pa.click('button[data-a=sv][data-v=Huye]');pa.click('button[data-a=sv][data-v=Nyagatare]');check('service areas selectable (separate from residence)',pa.locator('button[data-a=sv].on').count()==2)
    pa.screenshot(path=SH+'/02_register_step1.png');pa.click('#nx')
    check('step 2 visible',pa.is_visible('#rpf',timeout=2000) or pa.locator('.stp[data-s="2"]').is_visible())
    pa.click('#nx');check('photo is mandatory',pa.inner_text('#ep')=='Shyiraho nibura ifoto imwe.')
    reqs=[];pa.on('request',lambda r:reqs.append(r) if r.url.endswith('/api/register') else None)
    pa.set_input_files('#rpf',big[:3]);pa.wait_for_selector('#pv img >> nth=2',timeout=30000);check('3 large photos compressed client-side and previewed',pa.locator('#pv img').count()==3)
    pa.set_input_files('#rpf',[big[0]]);pa.wait_for_timeout(500);check('4th photo not accepted (max 3)',pa.locator('#pv img').count()==3)
    pa.click('summary:has-text("Ongeraho ibindi")');pa.fill('#ed','Perimi B');pa.fill('#so','https://example.com/jean');pa.screenshot(path=SH+'/03_register_photos.png');pa.click('#nx')
    pa.fill('#js','umushoferi');pa.check('input[name=job][value=Umushoferi]');check('capability picker shows counter 1 kuri 3','1 kuri 3' in pa.inner_text('#jc'));pa.click('#nx')
    pa.click('#nx');check('phone required + explicit visibility consent',MP:=('Andika telefoni nyayo' in pa.inner_text('#et')))
    pa.fill('#rt','0788123456');pa.fill('#rwa','0788123457');pa.click('summary:has-text("Izindi telefoni")');pa.fill('#rx0','0788123458');pa.fill('#rx1','0788123459')
    pa.click('#nx');check('consent required',pa.inner_text('#ev').startswith('Emeza'));pa.check('#rv');pa.click('#nx')
    pa.fill('#rm','jean@example.rw');pa.fill('#rw','short');pa.click('#nx');check('password min 8 enforced',('inyuguti 8' in pa.inner_text('#ew')))
    pa.fill('#rw','Password123');pa.fill('#rw2','DifferentPassword9');pa.click('#nx');check('password confirmation mismatch is rejected','Amagambo y’ibanga ntahura.' in pa.inner_text('#ewc'));pa.fill('#rw2','Password123');pa.click('#nx')
    pa.click('#nx');check('Terms must be accepted before account activation','Ugomba kwemera amabwiriza' in pa.inner_text('#eT'))
    check('Terms/Privacy links present in registration',pa.locator('a[href="/terms"]').count()>0 and pa.locator('a[href="/privacy"]').count()>0)
    pa.check('#rtm');pa.click('#nx');pa.wait_for_selector('text=Wiyandikishije neza',timeout=15000)
    body=reqs[-1].post_data or '';print('   register request payload KB:',len(body)//1024)
    check('image compression finished before upload (payload ≪ source photos)',len(body)<700*1024,len(body))
    users=jget('/api/profiles',dev='device-check-0000000001')['profiles'];prof=[x for x in users if x['name']=='Habimana Jean']
    check('account+profile persisted in shared DB',len(prof)==1);pid=prof[0]['pid'] if prof else None
    check('3 photos stored on server disk',all(os.path.exists(f'{DATA}/photos/{pid}-{i}.jpg') for i in range(3)) and os.path.exists(f'{DATA}/photos/{pid}-t.jpg'))
    check('session cookie is HttpOnly (not readable by JS)','ahs' not in pa.evaluate('document.cookie'))
    pa.screenshot(path=SH+'/04_registered.png')
    pa.click('button[data-a=full]');pa.wait_for_selector('.gal, img.main',timeout=5000)
    t=pa.inner_text('#sh');check('own full profile shows phones, service areas, freshness','0788123456' in t and '0788123458' in t and 'Akorera: Huye, Nyagatare' in t and 'Yavuguruwe vuba' in t,t[:300])
    pa.screenshot(path=SH+'/05_profile_mobile.png');pa.mouse.click(5,5)
    for i,(n,d,j) in enumerate([('Uwimana Peter','Huye',['Umushoferi']),('Hakizimana Olivier','Nyagatare',["Umukanishi w'imodoka"]),('Mugisha Eric','Nyagatare',['Woza imodoka']),('Uwase Diane','Huye',['Umudozi']),('Niyonsenga Eric','Musanze',['Umubaji']),('Ingabire Claudine','Rubavu',['Umutetsi']),('Bizimana Sam','Rwamagana',['Umushoferi'])],1):seed(n,d,j,i)
    xss=seed('<img src=x onerror=alert(1)>','Gasabo',['Umudozi'],20)
    print('\n[3] Second device (separate browser context) discovers the real profile')
    cb=b.new_context(viewport={'width':1280,'height':900},extra_http_headers={'x-forwarded-for':'5.5.5.2'});pb=cb.new_page();watch(pb,'B')
    pb.goto(BASE+'/');pb.wait_for_selector('#grid .card',timeout=8000)
    names=allnames(pb);check('User A registered on device A is visible on device B','Habimana Jean' in names,names)
    check('XSS name rendered as text, no script executed',any('<img' in n for n in names) and not dialogs,dialogs)
    allnames(pb);img=pb.locator('#grid .card').filter(has_text='Habimana Jean').locator('img');src=img.get_attribute('src');check('card uses lightweight thumbnail + lazy loading',src and '-t.jpg' in src and img.get_attribute('loading')=='lazy',src)
    nat=pb.evaluate("s=>new Promise(r=>{const i=new Image();i.onload=()=>r([i.naturalWidth,i.naturalHeight]);i.src=s})",src);check('thumbnail ≤160px',max(nat)<=160,nat)
    for q,expect in [('ndashaka umuntu utwara imodoka','Habimana Jean'),('I need a driver','Habimana Jean'),('mechanic','Hakizimana Olivier'),('umushofer','Uwimana Peter'),('car washing','Mugisha Eric'),('umuntu ushobora kunyoza imodoka','Mugisha Eric')]:
        pb.fill('#q',q);pb.wait_for_timeout(700);cards=allnames(pb);capok=expect in cards
        check(f'live search "{q}" (no Enter) finds {expect}',capok,cards)
    pb.fill('#q','astronaut');pb.wait_for_timeout(700);check('unknown skill → useful empty state, nobody invented','Nta muntu ubonetse hano' in pb.inner_text('#grid') and pb.locator('#grid .card').count()==0)
    pb.fill('#q','');pb.wait_for_timeout(500)
    print('\n[4] Location fallback in the UI')
    pb.fill('#q','umushoferi');pb.select_option('#fp','Iburasirazuba');pb.wait_for_timeout(600);pb.select_option('#fd','Nyagatare');pb.wait_for_timeout(800)
    tx=pb.inner_text('#grid');check('exact district → nearby → Rwanda fallback explained (Nyagatare has no driver but service-area match exists)','Habimana Jean' in tx and ('Hari 1 muri Nyagatare' in tx or 'Nta muntu ubonetse muri Nyagatare' in tx),tx[:200])
    pb.select_option('#fp','');pb.fill('#q','');pb.wait_for_timeout(600)
    print('\n[5] Public profile /u/:id, contact, share')
    allnames(pb);pb.locator('#grid .card').filter(has_text='Habimana Jean').click();pb.click('button[data-a=full]');pb.wait_for_selector('button[data-a=call]')
    check('URL becomes /u/:id when profile opened',f'/u/{pid}' in pb.url,pb.url)
    t=pb.inner_text('#sh');check('Hamagara + WhatsApp (only because supplied) + extra phones + Sangira + Bika + Menyesha ikibazo','Hamagara' in t and 'WhatsApp' in t and '0788123458' in t and 'Bika' in t and 'Menyesha ikibazo' in t and pb.locator('button[data-a=share]').count()==1,t[:300])
    check('Kunda removed (not an approved real feature)','Kunda' not in t)
    cp=b.new_context(viewport={'width':390,'height':844},extra_http_headers={'x-forwarded-for':'5.5.5.3'});pc=cp.new_page();watch(pc,'C')
    pc.goto(BASE+f'/u/{pid}');pc.wait_for_selector('button[data-a=call]',timeout=8000);check('/u/:id opens directly on a fresh device','Habimana Jean' in pc.inner_text('#sh'))
    pc.goto(BASE+'/u/doesnotexist1');pc.wait_for_selector('text=Umwirondoro ntubonetse',timeout=5000);check('unknown profile link handled',True)
    cp.close()
    print('\n[6] Login on device B, Bika, Rapora (Menyesha ikibazo)')
    userb,_=jpost('/api/register',dict(name='Visitor Bee',district='Kicukiro',jobs=['Umukozi wo mu rugo'],phone='0788777001',email='bee@example.rw',password='Password123',passwordConfirm='Password123',terms=True,photos=[T],thumbs=[T]))
    pb.click('button[data-a=save]');pb.wait_for_selector('#lp',timeout=3000);check('Bika requires login (login sheet shown)',True)
    pb.fill('#lp','bee@example.rw');pb.fill('#lw','wrong-pass');pb.click('#lb');pb.wait_for_selector('#le:has-text("si byo")',timeout=5000);check('wrong password: generic Kinyarwanda error',True)
    pb.fill('#lw','Password123');pb.click('#lb');pb.wait_for_selector('#toast:has-text("Winjiye neza")',timeout=5000)
    pb.goto(BASE+f'/u/{pid}');pb.wait_for_selector('button[data-a=save]');pb.click('button[data-a=save]');pb.wait_for_selector('button[data-a=save]:has-text("Wabitse")',timeout=5000)
    pb.goto(BASE+'/');pb.wait_for_selector('#grid .card .nm');pb.click('#bMenu');pb.click('#ms');pb.wait_for_selector('#sh:has-text("Habimana Jean")',timeout=5000);check('Bika persisted server-side: still saved after reload/new page load',True)
    pb.screenshot(path=SH+'/06_saved_desktop.png');pb.mouse.click(5,5);pb.wait_for_timeout(400);check('closing a profile restores the home URL',pb.url.rstrip('/')==BASE,pb.url)
    pb.goto(BASE+f'/u/{pid}');pb.wait_for_selector('button[data-a=save]:has-text("Wabitse")',timeout=5000);pb.click('button[data-a=save]');pb.wait_for_selector('button[data-a=save]:has-text("Bika")',timeout=5000);check('Bika can be removed',True);pb.click('button[data-a=save]');pb.wait_for_selector('button[data-a=save]:has-text("Wabitse")')
    pb.click('button[data-a=rep]');pb.check('input[name=rr] >> nth=2');pb.click('button[data-a=repOk]');pb.wait_for_selector('#toast:has-text("Amakuru yawe yakiriwe")',timeout=5000)
    ad,adc=jpost('/api/login',{'id':'admin@ahabona.rw','password':'AdminPass123'});ck=adc.split(';')[0]
    rp=jget('/api/admin/reports',cookie=ck)['reports'];check('report persisted and reached the admin API (not browser-local)',len(rp)==1 and rp[0]['reason']=='Imyitwarire mibi' and rp[0]['pid']==pid and rp[0]['reporter'],rp)
    print('\n[7] Discovery: device state, "11", refresh, intent, stats')
    cd=b.new_context(viewport={'width':1280,'height':900},extra_http_headers={'x-forwarded-for':'5.5.5.4'});pd=cd.new_page();watch(pd,'D')
    pd.goto(BASE+'/');pd.wait_for_selector('#grid .card .nm');first=pd.locator('#grid .card .nm').all_inner_texts()
    pd.goto(BASE+'/');pd.wait_for_selector('#grid .card .nm');again=pd.locator('#grid .card .nm').all_inner_texts();check('same device keeps its arrangement within 5 minutes',first==again,(first,again))
    pd.evaluate('refresh()');pd.wait_for_timeout(900);changed=pd.locator('#grid .card .nm').all_inner_texts();check('refresh (idle/return) produces a new arrangement of the same people',changed!=first and len(changed)==len(first),(first,changed))
    pd.fill('#q','11');pd.wait_for_selector('#toast:has-text("Wasubiye aho watangiriye")',timeout=5000);pd.wait_for_timeout(700);restored=pd.locator('#grid .card .nm').all_inner_texts();check('"11" restores the original starting arrangement',restored==first and pd.input_value('#q')=='',(first,restored))
    pd.locator('#grid .card').first.click();pd.wait_for_timeout(500);pd.mouse.click(5,5)
    s=jget('/api/admin/summary',cookie=ck);check('impressions / opens recorded as real stats',s['impressions_total']>5 and s['profile_opens_total']>=1,s)
    check('different devices get different sequences (A vs D)',pb.evaluate("localStorage.getItem('ahabona_device')")!=pd.evaluate("localStorage.getItem('ahabona_device')"))
    cd.close()
    print('\n[8] Edit profile (incl. photo removal) → visible to others')
    print('DEBUG url',pa.url);pa.reload();
    try:pa.wait_for_selector('#grid .card .nm',timeout=8000)
    except Exception:
        print('DEBUG grid:',pa.inner_text('#grid')[:200],'| overlay:',pa.locator('#ov.on').count(),'| url',pa.url,'| errors',errors[-3:]);pa.screenshot(path=SH+'/debug.png');raise
    pa.click('#bReg');pa.click('button[data-a=edit]');pa.fill('#rn','Habimana Jean Pierre')
    pa.click('#nx');pa.click('button[data-a=rmph][data-i="2"]');pa.click('#nx');pa.click('#nx');pa.fill('#rwa','0788123400');pa.click('#nx')
    pa.wait_for_selector('#toast:has-text("Umwirondoro wawe wavuguruwe")',timeout=15000)
    pr=jget(f'/api/profile/{pid}')['profile'];check('edit saved on server: new name, 2 photos, new WhatsApp',pr['name']=='Habimana Jean Pierre' and len(pr['photos'])==2 and pr['wa']=='0788123400',pr)
    pb.goto(BASE+'/');pb.wait_for_selector('#grid .card .nm');check('device B sees the edited profile',('Habimana Jean Pierre' in allnames(pb)))
    print('\n[9] Account deletion → hidden → recovery')
    pa.click('#bReg');pa.click('summary:has-text("Igenamiterere")');pa.click('button[data-a=del]');pa.fill('#dpw','bad');pa.click('button[data-a=delOk]');pa.wait_for_selector('#de:has-text("si ryo")',timeout=5000)
    pa.fill('#dpw','Password123');pa.click('button[data-a=delOk]');pa.wait_for_selector('text=Gusiba konti byakiriwe',timeout=8000)
    pb.reload();pb.wait_for_selector('#grid .card .nm');check('deleted profile disappears from public discovery immediately','Habimana Jean Pierre' not in allnames(pb))
    pb.goto(BASE+f'/u/{pid}');pb.wait_for_selector('text=Umwirondoro ntubonetse',timeout=5000);check('deleted profile URL no longer public',True)
    pa.mouse.click(5,5);pa.wait_for_timeout(600);pa.reload();pa.click('#bMenu');pa.click('button[data-m=login]');pa.fill('#lp','jean@example.rw');pa.fill('#lw','Password123');pa.click('#lb');pa.wait_for_selector('text=iri mu gihe cyo gusibwa',timeout=8000)
    pa.click('button[data-a=restore]');pa.wait_for_selector('#toast:has-text("yasubijwe")',timeout=8000)
    pb.goto(BASE+'/');pb.wait_for_selector('#grid .card .nm');check('recovered within 6 months → visible again','Habimana Jean Pierre' in allnames(pb))
    print('\n[10] Admin UI + moderation')
    cad=b.new_context(viewport={'width':1100,'height':800},extra_http_headers={'x-forwarded-for':'5.5.5.9'});pad=cad.new_page();watch(pad,'ADMIN')
    pad.goto(BASE+'/admin');pad.fill('#e','jean@example.rw');pad.fill('#p','Password123');pad.click('button:has-text("Injira")');pad.wait_for_selector('.err:has-text("si iy")',timeout=5000);check('normal user cannot enter admin UI',True)
    pad.fill('#e','admin@ahabona.rw');pad.fill('#p','AdminPass123');pad.click('button:has-text("Injira")');pad.wait_for_selector('th:has-text("profiles public")',timeout=8000);check('admin sees real summary',True)
    pad.click('nav button:has-text("Ibibazo")');pad.wait_for_selector('td:has-text("Imyitwarire mibi")',timeout=5000);check('admin sees the report',True)
    pad.click('nav button:has-text("Abakoresha")');pad.wait_for_selector('tr:has-text("Habimana Jean Pierre")');pad.locator('tr:has-text("Habimana Jean Pierre") button').click();pad.wait_for_timeout(800)
    pb.reload();pb.wait_for_selector('#grid .card .nm');check('admin suspension hides the profile publicly','Habimana Jean Pierre' not in allnames(pb))
    pad.locator('tr:has-text("Habimana Jean Pierre") button').click();pad.wait_for_timeout(800);check('admin restore works',len([x for x in jget('/api/profiles',dev='device-check-0000000002')['profiles'] if x['name']=='Habimana Jean Pierre'])==1)
    pad.screenshot(path=SH+'/07_admin.png')
    print('\n[11] Help assistant, legal pages, About')
    pb.goto(BASE+'/');pb.wait_for_selector('#grid .card .nm');pb.click('#bMenu');pb.click('button[data-m=help]');pb.fill('#ha','Nibagiwe ijambobanga');pb.click('button[data-a=ask]');pb.wait_for_selector('#hr b',timeout=5000);check('help assistant answers from approved content',('Injira' in pb.inner_text('#hr')))
    pb.fill('#ha','xyzzy plugh');pb.click('button[data-a=ask]');pb.wait_for_timeout(500);check('help assistant admits when it has no grounded answer','Sinabonye igisubizo' in pb.inner_text('#hr'))
    pb.goto(BASE+'/terms');check('Terms page',pb.locator('h2:has-text("Not a Job-Advertising Platform")').count()==1);pb.goto(BASE+'/privacy');check('Privacy page',pb.locator('h2:has-text("Retention and deletion")').count()==1)
    print('\n[12] Forgot password through the real flow')
    pb.goto(BASE+'/');pb.click('#bMenu');pb.click('button[data-m=login]');pb.click('button[data-a=forgot]') if False else None
    pe=b.new_context(viewport={'width':390,'height':844},extra_http_headers={'x-forwarded-for':'5.5.5.8'}).new_page();watch(pe,'E');pe.goto(BASE+'/');pe.click('#bMenu');pe.click('button[data-m=login]');pe.click('button[data-a=forgot]');pe.fill('#fe','bee@example.rw');pe.click('button[data-a=doForgot]');pe.wait_for_selector('#fm:has-text("Niba iyi email ibaho")',timeout=5000)
    tok=[m for m in json.load(urllib.request.urlopen(BASE+'/api/_dev/mail'))['mail'] if m['to']=='bee@example.rw'][-1]['text'].split('/reset/')[1].strip()
    pe.goto(BASE+'/reset/'+tok);pe.fill('#np1','NewPassword456');pe.click('button[data-a=doReset]');pe.wait_for_selector('#lp',timeout=5000);pe.fill('#lp','bee@example.rw');pe.fill('#lw','NewPassword456');pe.click('#lb');pe.wait_for_selector('#toast:has-text("Winjiye neza")',timeout=5000);check('reset link → new password → login works',True)
    print('\n[13] Security / console health')
    cspv=[x for pg in (pa,pb,pd,pe,pad) for x in (pg.evaluate('window.__csp') if not pg.is_closed() else [])]
    check('no CSP violations in any page',not cspv,cspv)
    check('no unexpected JS errors',not errors,errors[:5])
    check('no alert()/XSS execution',not dialogs,dialogs)
    pa.goto(BASE+'/');pa.wait_for_selector('#grid .card .nm');pa.screenshot(path=SH+'/08_home_mobile.png')
    pb.goto(BASE+'/');pb.wait_for_selector('#grid .card .nm');pb.screenshot(path=SH+'/09_home_desktop.png')
    b.close()
finally:
    srv.terminate();shutil.rmtree(DATA,ignore_errors=True)
print(f'\n=== E2E RESULT: {sum(res)} passed, {len(res)-sum(res)} failed ===')
sys.exit(0 if all(res) else 1)
